﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSColorThemeProcessor
{
    class Program
    {
        private const int COLOR_COMPONENT_INCREMENT = 25;

        static void Main(string[] args)
        {
            string inputFileName = "BasisEditorDark.vstheme";
            string outputFileName = "BasisEditorNormal.vstheme";

            const string COLOR_START_MARKER = "Source=\"";

            string[] inputLines = System.IO.File.ReadAllLines(inputFileName);

            Dictionary<string, string> colorMappings = new Dictionary<string, string>();

            // Run through all lines and process the colors found.
            foreach(string inputLine in inputLines)
            {
                int colorStartIndex = inputLine.IndexOf(COLOR_START_MARKER);
                int colorEndIndex = -1;

                if(colorStartIndex != -1)
                {
                    string restOfLine = inputLine.Substring(colorStartIndex + COLOR_START_MARKER.Length);

                    colorEndIndex = restOfLine.IndexOf("\"");

                    if (colorEndIndex == 8)
                    {
                        string color = inputLine.Substring(colorStartIndex + COLOR_START_MARKER.Length, 8);

                        if(!colorMappings.ContainsKey(color))
                        {
                            colorMappings.Add(color, ProcessColor(color, false));
                        }
                    }
                }
            }

            // Write the processed lines to a new list.

            List<string> outputLines = new List<string>();
            foreach (string inputLine in inputLines)
            {
                string newLine = inputLine;
                foreach (KeyValuePair<string, string> mapping in colorMappings)
                {
                    newLine = newLine.Replace(mapping.Key, mapping.Value);
                }

                outputLines.Add(newLine);
            }

            System.IO.File.WriteAllLines(outputFileName, outputLines.ToArray());

            // Calculate the foreground and background colors that are passed directly to the program. Calculate based on the values
            // specified for the dark theme + COLOR_COMPONENT_INCREMENT.

            Console.WriteLine("mBackgroundColor: " + ProcessColor("FF212121", true));
            Console.WriteLine("mForegroundColor: " + ProcessColor("FFA0A0A0", true));
        }

        static string ProcessColor(string color, bool outputDecimalComponents)
        {
            if(color.Length != 8)
            {
                throw new Exception("Invalid color string.");
            }

            string alphaString = color.Substring(0, 2);
            string redString = color.Substring(2, 2);
            string greenString = color.Substring(4, 2);
            string blueString = color.Substring(6, 2);

            int originalRed = int.Parse(redString, System.Globalization.NumberStyles.HexNumber);
            int originalGreen = int.Parse(greenString, System.Globalization.NumberStyles.HexNumber);
            int originalBlue = int.Parse(blueString, System.Globalization.NumberStyles.HexNumber);

            int newRed = originalRed + COLOR_COMPONENT_INCREMENT;
            int newGreen = originalGreen + COLOR_COMPONENT_INCREMENT;
            int newBlue = originalBlue + COLOR_COMPONENT_INCREMENT;

            newRed = Math.Max(0, Math.Min(255, newRed));
            newGreen = Math.Max(0, Math.Min(255, newGreen));
            newBlue = Math.Max(0, Math.Min(255, newBlue));

            if(outputDecimalComponents)
            {
                Console.WriteLine("  Red: " + newRed.ToString());
                Console.WriteLine("  Green: " + newGreen.ToString());
                Console.WriteLine("  Blue: " + newBlue.ToString());
            }

            string newColor = alphaString + newRed.ToString("X2") + newGreen.ToString("X2") + newBlue.ToString("X2");

            return newColor;
        }
    }
}
